﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14_AaronNajera_1059726
{
    public class Producto
    {
        public int Cantidad { get; set; }
        public string Nombre { get; set; }
        public decimal Precio { get; set; }

        public Producto(string nombre, decimal precio, int cantidad)
        {
            Nombre = nombre;
            Precio = precio;
            Cantidad = cantidad;
        }
        public void Vender(int cantidadVendida)
        {
            if (cantidadVendida <= 0)
            {
                Console.WriteLine("[Error] La cantidad a vender debe ser mayor a cero.");
            }
            else if (Cantidad >= cantidadVendida)
            {
                Cantidad -= cantidadVendida;
                Console.WriteLine($"[Venta Exitosa] Se vendieron {cantidadVendida} unidades de '{Nombre}'.");
            }
            else
            {
                Console.WriteLine($"[Error] Stock insuficiente. Solo hay {Cantidad} unidades disponibles de '{Nombre}'.");
            }
        }
        public void Reabastecer(int cantidadNueva)
        {
            if (cantidadNueva > 0)
            {
                Cantidad += cantidadNueva;
                Console.WriteLine($"[Reabastecimiento] Ingresaron {cantidadNueva} unidades nuevas de '{Nombre}'.");
            }
            else
            {
                Console.WriteLine("[Error] La cantidad a reabastecer debe ser mayor a cero.");
            }
        }
            public void MostrarInformacion()
        {
            Console.WriteLine($"Producto: {Nombre} | Precio: Q{Precio:F2} | Stock: {Cantidad} unidades");
        }
    }
    }


