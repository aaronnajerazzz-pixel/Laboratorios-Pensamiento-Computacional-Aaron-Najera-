﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14_AaronNajera_1059726
{
    internal class Program
    {
        static void Main(string[] args)
        {
        //Ejercicio 1
        Console.WriteLine("//////////////CUENTA BANCARIA//////////////");
            CuentaBancaria cuenta1 = new CuentaBancaria("Aaron Najera", "Bac-1059726",1500);
            CuentaBancaria cuenta2 = new CuentaBancaria("Pablo Najera", "Bac-1080927", 300);
            cuenta1.MostrarInformacion();
            cuenta2.MostrarInformacion();
            Console.WriteLine();

            Console.WriteLine("--- Operaciones: Cuenta de Aarón ---");
            Console.WriteLine("Saldo antes del depósito: Q" +cuenta1.Saldo);
            cuenta1.Depositar(250.00m);
            Console.WriteLine("Saldo después del depósito: Q" + cuenta1.Saldo);

            Console.WriteLine("Saldo antes del retiro: Q" + cuenta1.Saldo);
            cuenta1.Retirar(2000.00m); 
            Console.WriteLine("Saldo después del intento de retiro: Q" + cuenta1.Saldo);

            Console.WriteLine("--- Operaciones: Cuenta de Pablo ---");
            Console.WriteLine("Saldo antes del retiro: Q" + cuenta2.Saldo);
            cuenta2.Retirar(300.00m);
            Console.WriteLine("Saldo después del retiro: Q" + cuenta2.Saldo);

            Console.WriteLine("Saldo antes del depósito: Q" + cuenta2.Saldo);
            cuenta2.Depositar(150.75m);
            Console.WriteLine("Saldo después del depósito: Q" + cuenta2.Saldo);

     
            Console.WriteLine("=== ESTADO FINAL DE LAS CUENTAS ===");
            cuenta1.MostrarInformacion();
            cuenta2.MostrarInformacion();

            //Ejercicio 2
            Console.WriteLine("//////////////Gestion Tienda//////////////");
            Producto producto1 = new Producto("Laptop", 999.99m, 10);
            Producto producto2 = new Producto("Smartphone", 499.99m, 20);
            Console.WriteLine("Estado inicial de los productos:");
            producto1.MostrarInformacion();
            producto2.MostrarInformacion();

            Console.WriteLine();
            Console.WriteLine("--- Operaciones: Producto Laptop ---");
            Console.WriteLine("Cantidad antes de la venta:" + producto1.Cantidad);
            producto1.Vender(5);
            Console.WriteLine("Cantidad después de la venta:" + producto1.Cantidad);
            Console.WriteLine("--- Operaciones: Producto Smartphone ---");
            Console.WriteLine("Stock antes del reabastecimiento" + producto2.Cantidad);
            producto2.Reabastecer(12);
            Console.WriteLine("Stock después del reabastecimiento:" + producto2.Cantidad);
            Console.WriteLine("--------Inventario Actualizado---------");
            producto1.MostrarInformacion();
            producto2.MostrarInformacion();

            //Ejercicio 3
            Console.WriteLine("///////////// NOTAS ESTUDIANTES //////////////");
            decimal[] notasEstudiante1 = { 50.0m, 60.5m, 45.0m };
            Estudiante estudiante1 = new Estudiante("Aarón", 18, "Ingeniería en Sistemas", notasEstudiante1);

            decimal[] notasEstudiante2 = { 85.5m, 90.0m, 78.0m };
            Estudiante estudiante2 = new Estudiante("Julia", 18, "Ingeniería en Sistemas", notasEstudiante2);
            Console.WriteLine("--- Registro Inicial ---");
            estudiante1.MostrarInformacion();
            estudiante1.Aprobar();

            Console.WriteLine("------------------------");

            estudiante2.MostrarInformacion();
            estudiante2.Aprobar();

            Console.WriteLine("=== ACTUALIZACIÓN DE NOTAS ===");
            estudiante1.AgregarNota(95.0m);
            //Eso va a pasar en todas las clases estoy seguro gano gano si si 
            Console.WriteLine("--- Registro Actualizado de Aaron ---");
            estudiante1.MostrarInformacion(); 
            estudiante1.Aprobar();

        }

    }
}
