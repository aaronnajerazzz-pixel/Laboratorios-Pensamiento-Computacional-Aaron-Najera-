﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14_AaronNajera_1059726
{
    public class CuentaBancaria 
    {
        public string Titular { get; set; }
        public string NumeroCuenta { get; set; }
        public decimal Saldo { get; private set; }

        public CuentaBancaria(string titular, string numeroCuenta, decimal saldoInicial)
        {
            Titular = titular;
            NumeroCuenta = numeroCuenta;
            Saldo = saldoInicial;
        }
        public void Depositar(decimal cantidad)
        {
            if (cantidad > 0)
            {
                Saldo += cantidad;
                Console.WriteLine($"Depósito exitoso. Nuevo saldo: {Saldo:C}");
            }
            else
            {
                Console.WriteLine("La cantidad a depositar debe ser mayor que cero.");
            }
        }
        public void Retirar(decimal cantidad)
        {
            if (cantidad > 0)
            {
                if (Saldo >= cantidad)
                {
                    Saldo -= cantidad;
                    Console.WriteLine($"Retiro exitoso. Nuevo saldo: {Saldo:C}");
                }
                else
                {
                    Console.WriteLine("Fondos insuficientes para realizar el retiro.");
                }
            }
            else
            {
                Console.WriteLine("La cantidad a retirar debe ser mayor que cero.");
            }

        }
        public void MostrarInformacion()
        {
            Console.WriteLine($"Titular: {Titular} | No. Cuenta: {NumeroCuenta} | Saldo: Q{Saldo:F2}");
        }
    }
}
