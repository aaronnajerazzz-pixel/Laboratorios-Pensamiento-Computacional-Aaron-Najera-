﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab14_AaronNajera_1059726
{
    public class Estudiante
    {

        public string nombre;
        public int edad;
        public string grado;
        public decimal[] notas;

    public Estudiante(string nombre, int edad, string grado, decimal[] notas)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.grado = grado;
            this.notas = notas;
        }
    public decimal CalcularPromedio()
        {
            if (notas.Length == 0)
            {
                Console.WriteLine("[Error] No se han ingresado notas para calcular el promedio.");
                return 0;
            }
            decimal suma = 0;
            foreach (decimal nota in notas)
            {
                suma += nota;
            }
            return suma / notas.Length;
        }
        public void MostrarInformacion()
        {
            Console.WriteLine($"Nombre: {nombre} | Edad: {edad} años | Grado: {grado}");
            Console.WriteLine("Notas:");
            for (int i = 0; i < notas.Length; i++)
            {
                Console.WriteLine($"  Nota {i + 1}: {notas[i]:F2}");
            }
            Console.WriteLine($"Promedio: {CalcularPromedio():F2}");
        }
        public void Aprobar()
        {
            decimal promedio = CalcularPromedio();
            if (promedio >= 61m)
            {
                Console.WriteLine($"[Aprobado] El estudiante '{nombre}' ha aprobado con un promedio de {promedio:F2}.");
            }
            else
            {
                Console.WriteLine($"[Reprobado] El estudiante '{nombre}' ha reprobado con un promedio de {promedio:F2}.");
            }
        }
            public void AgregarNota(decimal nuevaNota)
            {
                if (nuevaNota >= 0 && nuevaNota <= 100)
                {
                    Array.Resize(ref notas, notas.Length + 1);
                    notas[notas.Length - 1] = nuevaNota;
                    Console.WriteLine($"[Nota Agregada] Se ha agregado la nota {nuevaNota:F2} para el estudiante '{nombre}'.");
                }
                else
                {
                    Console.WriteLine("[Error] La nota debe estar entre 0 y 100.");
            }
        }
    }
}
