﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12_NajeraAaron_1059726
{
    internal class Program
    {
        //Ejercicio 1
        static void Main(string[] args)
        {
            int[,] matriz = new int[5, 5];
            Llenar(matriz);
            Console.WriteLine("Esta es la matriz 5x5:");
            MostrarMatriz(matriz);
            int sumaPrincipal = SumarDiagonalPrincipal(matriz);
            int SumaSecundaria = SumarDiagonalSecundaria(matriz);
            Console.WriteLine($"\nLa suma de la diagonal principal es: {sumaPrincipal}");
            Console.WriteLine($"Suma de la diagonal secundaria es: {SumaSecundaria}");
        
        //Ejercicio 2

            int[,] matriz2 = new int[4, 6];
            Llenar(matriz2);
            Console.WriteLine("==EJERCICIO 2==");
            Console.WriteLine("Esta es la matriz 4x6:");
            MostrarMatriz(matriz2);
            int CantidadPares = ContarPares(matriz2);
            int CantidadImpares = ContarImpares(matriz2);
            Console.WriteLine($"\nLa cantidad de números pares es: {CantidadPares}");
            Console.WriteLine($"La cantidad de números impares es: {CantidadImpares}");
        
        //Ejercicio 3 

            float[,] notas = new float[5, 4];
            IngresarNotas(notas);
            Console.WriteLine("=== Reporte de Notas ===\n");
            for (int i = 0; i < 5; i++)
            {
                float promedio = Promedio(notas, i);
                bool estado = Aprueba(promedio);
                string estadoTexto;
                if (estado == true)
                {
                    estadoTexto = "Aprobado";
                }
                else
                {
                    estadoTexto = "Reprobado";
                }
                Console.WriteLine($"Estudiante {i + 1}: Promedio = {promedio:F2} \tEstado:{estadoTexto}");
            }
            Console.WriteLine();
        //Ejercicio 4
            int[,] matriz3 = new int[3, 3];
            Llenar(matriz3);
            Console.WriteLine("==EJERCICIO 4==");
            Console.WriteLine("Esta es la matriz 3x3:");
            MostrarMatriz(matriz3);
            if (EsSimetrica(matriz3))
                Console.WriteLine("\nLa matriz ES simétrica.");
            else
                Console.WriteLine("\nLa matriz NO es simétrica.");
        }
        //Ejercicio 1
        static void Llenar(int[,] matriz)
        {
            Random rand = new Random();
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    matriz[i, j] = rand.Next(1, 10);
                }
            }
        }
        static void MostrarMatriz(int[,] matriz)
        {
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                for (int j = 0; j < matriz.GetLength(1); j++)
                {
                    Console.Write(matriz[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
        static int SumarDiagonalPrincipal(int[,] matriz)
        {
            int suma = 0;
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                suma += matriz[i, i];
            }
            return suma;
        }
        static int SumarDiagonalSecundaria(int[,] matriz)
        {
            int suma = 0;
            for (int i = 0; i < matriz.GetLength(0); i++)
            {
                suma += matriz[i, matriz.GetLength(1) - 1 - i];
            }
            return suma;
        }
        //Ejercicio 2
        static int ContarPares(int[,] m)
        {
            int contador = 0;
            foreach (int num in m)
                if (num % 2 == 0) contador++;
            return contador;
        }

        static int ContarImpares(int[,] m)
        {
            int contador = 0;
            foreach (int num in m)
                if (num % 2 != 0) contador++;
            return contador;
        }
        //Ejercicio 3
        static void IngresarNotas(float[,] m)
        {
            Random rnd = new Random();
            for (int i = 0; i < 5; i++) 
            {
                for (int j = 0; j < 4; j++) 
                {
                    m[i, j] = rnd.Next(40, 101);
                }
            }
        }
        static float Promedio(float[,] m, int estudiante)
        {
            float suma = 0;
            int cantidadNotas = m.GetLength(1);
            for (int j = 0; j < cantidadNotas; j++) suma += m[estudiante, j];
            return suma / cantidadNotas;
        }

        static bool Aprueba(float promedio)
        {
            return promedio >= 61;
        }
        //Ejercicio 4
        static bool EsSimetrica(int[,] m)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (m[i, j] != m[j, i])
                        return false;
                }
            }
            return true;
        }
    }
}
        
    

