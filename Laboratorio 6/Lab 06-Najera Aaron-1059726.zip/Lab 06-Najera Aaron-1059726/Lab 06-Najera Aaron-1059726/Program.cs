﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Lab_06_Najera_Aaron_1059726
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------Convercion de temperatura------------");
            Console.WriteLine("1. Celsius a Fahrenheit");
            Console.WriteLine("2. Fahrenheit a Celsius");
            Console.WriteLine("3. Celsius a Kelvin");
            String opcion = Console.ReadLine();
            int opcionInt = Convert.ToInt32(opcion);
            Console.WriteLine("Ingrese la temperatura a convertir: ");
            string temperatura = Console.ReadLine();
            double temperaturaDouble = Convert.ToDouble(temperatura);
            double resultado = 0;
            Console.WriteLine("------------------TEMPERATURA CONVERTIDA------------------");
            switch
                (opcionInt)
            {
                case 1:
                    resultado = (temperaturaDouble * 9 / 5) + 32;
                    Console.WriteLine("La temperatura en Fahrenheit es: " + resultado);
                    break;
                case 2:
                    resultado = (temperaturaDouble - 32) * 5 / 9;
                    Console.WriteLine("La temperatura en Celsius es: " + resultado);
                    break;
                case 3:
                    resultado = temperaturaDouble + 273.15;
                    Console.WriteLine("La temperatura en Kelvin es: " + resultado);
                    break;
                default:
                    Console.WriteLine("Opcion no valida");
                    break;
            }
            // Ejercicio 2
            Console.WriteLine("------------DESCUENTOS EN LA TIENDA------------");
            Console.WriteLine("Ingresa que tipo de cliente eres (1 / 2)");
            Console.WriteLine("1. Cliente Normal");
            Console.WriteLine("2. Cliente VIP");
            String Cliente = Console.ReadLine();
            int tipoCliente = Convert.ToInt32(Cliente);
            Console.WriteLine("Ingresa el monto total de tu compra: ");
            string entradaUnidades = Console.ReadLine();
            int unidades = Convert.ToInt32(entradaUnidades);
            Console.WriteLine("------------------TU DESCUENTO SERA DE------------------");
            if (unidades > 100)
            {
                Console.WriteLine("Obtienes el descuento de MAYORISTA: 15%");
            }
            else if (tipoCliente == 1)
            {
                Console.WriteLine("Obtienes el descuento de Cliente REGULAR: 5%");
            }
            else if (tipoCliente == 2)
            {
                Console.WriteLine("Obtienes el descuento de Cliente VIP: 10%");
            }
            else
            {
                Console.WriteLine("Opción de cliente no válida.");
            }

            Console.WriteLine("------------------------------------------------------");

            // ejercicio 3
            Console.WriteLine("------------PRECIO DEL ESTACIONAMIENTO------------");
            Console.WriteLine("Cuantas horas has estado estacionado?");
            string horasEntrada = Console.ReadLine();
            int horas = Convert.ToInt32(horasEntrada);
            double totalPagar = 0;
            if (horas < 2)
            {
                totalPagar = horas * 5;
            }
            else if (horas <= 5)
            {
                totalPagar = horas * 4;
            }
            else
            {
                totalPagar = horas * 3;
            }
            Console.WriteLine("El total a pagar por el estacionamiento es: " + totalPagar);
            // ejercicio 4
            double ingresofijo = 2400;
            Console.WriteLine("------------CALIFICACION DE UN ESTUDIANTE------------");
            Console.WriteLine("Ingresa la calificacion 0.0, 0.4, 0.6 o mas: ");
            double puntuacion = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("------------------Lo que ganaras sera------------------");
            double premio = ingresofijo * puntuacion;
            switch
                (puntuacion)
            {
                case 0.0:
                    Console.WriteLine("Tu calificacion es inaceptable");
                    Console.WriteLine("te quedaras con 2400");
                    break;
                case 0.4:
                    Console.WriteLine("Tu calificacion es aceptable");
                    Console.WriteLine("te quedaras con 2400" + premio);
                    break;
                case 0.6:
                    Console.WriteLine("Tu calificacion es meritorio");
                    Console.WriteLine("te quedaras con 2400" + premio);
                    break;
                default:
                    Console.WriteLine("Tu calificacion es invalida, no se pueden numeros intermedios");
                    break;
            }
        }
    }
}
