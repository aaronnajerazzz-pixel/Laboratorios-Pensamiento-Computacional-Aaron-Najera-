﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L08_Najera_Aaron_1059726
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            int Mayor = int.MinValue;
            int Menor = int.MaxValue;
            int numero;

            for (int i = 1; i <= 20; i++)
            {
                Console.Write("Ingrese el número " + i + ": ");
                numero = int.Parse(Console.ReadLine());
                if (numero > Mayor)
                {
                    Mayor = numero;
                }

                if (numero < Menor)
                {
                    Menor = numero;
                }

                suma += numero;
            }

            double promedio = (double)suma / 20;

            Console.WriteLine("El numero menor es: " + Menor);
            Console.WriteLine("El numero mayor es: " + Mayor);
            Console.WriteLine("El promedio de los numeros es: " + promedio);
            //ejercicio2
            Console.WriteLine("Ejercicio 2: Numeros del 1 al 100");
            for (int i = 1; i <= 100; i++)
            {
                if(i % 2 == 0 && i % 7 == 0) { 
                    Console.WriteLine("PAR DE SIETE");
                }
                else if (i % 2 == 0)
                {
                    Console.WriteLine("PAR");
                }
                else if (i % 7 == 0) {
                    Console.WriteLine("Siete");
                }
                else {
                    Console.WriteLine(i);
                }
            //Ejercicio 3
              int clientecondescuento = 0;
                double VentaTotal = 0;
                for ( i = 1; i <= 10; i++)
                {
                    Console.Write("Ingrese el monto de la venta " + i + ":");
                    double compra = double.Parse(Console.ReadLine());
                    double descuento = 0;
                    if (compra > 700)
                    {
                        descuento = compra * 0.12;
                        clientecondescuento++;
                    }
                    else if (compra > 300)
                    {
                        descuento = compra * 0.05;
                        clientecondescuento++;
                    }
                    double total = compra - descuento;
                    VentaTotal += total;
                    Console.WriteLine("El total a pagar es: " + total);
                }
                Console.WriteLine("Clientes con descuento" + clientecondescuento);
                Console.WriteLine("Venta total: " + VentaTotal);

                //Ejercicio 5
                Console.WriteLine("Escribe la cantidad de filas que quieras");
                int filas = int.Parse(Console.ReadLine());
                for ( i = 1; i <= filas; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();



                }
                }
        }
    }
}
    

