﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto2_Aaron
{
    class Parcela
    {
        public string tipoSiembra = "Vacia";
        public bool estaOcupada = false;
        public int mesesCrecimiento = 0;
        public int mesesFaltantes = 0;
        public double ingresosEsperados = 0.0;

        public void SembrarCultivo(string nombre, int mCrecimiento, double ganancia)
        {
            this.tipoSiembra = nombre;
            this.estaOcupada = true;
            this.mesesCrecimiento = mCrecimiento;
            this.mesesFaltantes = mCrecimiento;
            this.ingresosEsperados = ganancia;
        }

        public void CosecharCultivo()
        {
            this.estaOcupada = false;
            this.tipoSiembra = "Vacia";
            this.mesesCrecimiento = 0;
            this.mesesFaltantes = 0;
            this.ingresosEsperados = 0.0;
        }
    }
}
