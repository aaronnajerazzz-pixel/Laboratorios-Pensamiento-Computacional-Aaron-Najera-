﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto2_Aaron
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("//// BIENVENIDO A LA GESTIÓN DE GRANJA ////");

            // Datos Iniciales y Validación de Entradas
            double dineroInicial;
            Console.WriteLine("\nIngrese la cantidad de dinero inicial (Q):");
            while (!double.TryParse(Console.ReadLine(), out dineroInicial) || dineroInicial <= 0)
            {
                Console.WriteLine("inválida. Debe ser un número mayor a 0:");
            }

            int numEmpleados;
            Console.WriteLine("Ingrese el número de empleados:");
            while (!int.TryParse(Console.ReadLine(), out numEmpleados) || numEmpleados < 1)
            {
                Console.WriteLine("inválida. Debe ser 1 o más:");
            }

            double sueldoMensual;
            Console.WriteLine("Ingrese el sueldo mensual por empleado (Q):");
            while (!double.TryParse(Console.ReadLine(), out sueldoMensual) || sueldoMensual <= 0)
            {
                Console.WriteLine("inválida. Debe ser mayor a 0:");
            }

            int mesesSimular;
            Console.WriteLine("Ingrese la cantidad de meses por simular:");
            while (!int.TryParse(Console.ReadLine(), out mesesSimular) || mesesSimular < 1)
            {
                Console.WriteLine("inválida. Debe ser 1 o más:");
            }

            int numFilas;
            Console.WriteLine("Ingrese la cantidad de filas para las parcelas:");
            while (!int.TryParse(Console.ReadLine(), out numFilas) || numFilas < 1)
            {
                Console.WriteLine("inválida. Debe ser 1 o más:");
            }

            int numColumnas;
            Console.WriteLine("Ingrese la cantidad de columnas para las parcelas:");
            while (!int.TryParse(Console.ReadLine(), out numColumnas) || numColumnas < 1)
            {
                Console.WriteLine("inválida. Debe ser 1 o más:");
            }

            // Crear la parcela 
            Parcela[,] granja = new Parcela[numFilas, numColumnas];
            for (int f = 0; f < numFilas; f++)
            {
                for (int c = 0; c < numColumnas; c++)
                {
                    granja[f, c] = new Parcela();
                }
            }

            // Variables de control y acumulados
            double dinero = dineroInicial;
            int mesesRestantes = mesesSimular;
            int mesesEfectivamenteSimulados = 0;
            bool salir = false;

            int invTrigo = 0;
                int invRepollo = 0;
                int invTomate = 0;
                int invCalabaza = 0; 
               int  invEsparrago = 0;
            double totalIngresos = 0.0;
            double totalMatPrima = 0.0;

            // Menu principal de la simulación
            while (mesesRestantes > 0 && dinero > 0 && !salir)
            {
                Console.WriteLine("\n-----------------------------------------------------------------");
                Console.WriteLine($"Meses restantes: {mesesRestantes} | Dinero en caja: Q{dinero:F2}");
                Console.WriteLine("-------------------------------------------------------------------");
                Console.WriteLine("1. Comprar Semillas");
                Console.WriteLine("2. Sembrar");
                Console.WriteLine("3. Consultar parcelas");
                Console.WriteLine("4. Avanzar de mes");
                Console.WriteLine("5. Salir");
                Console.WriteLine("--------------------------------------------------------------------");

                int opcion;
                Console.WriteLine("Seleccione uno:");
                while (!int.TryParse(Console.ReadLine(), out opcion) || opcion < 1 || opcion > 5)
                {
                    Console.WriteLine("inválida. Seleccione una opción del 1 al 5:");
                }

                switch (opcion)
                {
                    case 1: // Comprar
                        double costosMensuales = numEmpleados * sueldoMensual;
                        double utilidad = dinero - costosMensuales;

                        Console.WriteLine("\n--- Información Financiera ---");
                        Console.WriteLine($"Caja: Q{dinero:F2}");
                        Console.WriteLine($"Costos mensuales proyectados: Q{costosMensuales:F2}");
                        Console.WriteLine($"Utilidad proyectada: Q{utilidad:F2}");

                        if (utilidad >= 0)
                        {
                            Console.WriteLine("\n--- Catálogo de Semillas ---");
                            Console.WriteLine("1. Trigo     (Costo: Q100 | Ingreso: Q130)");
                            Console.WriteLine("2. Repollo   (Costo: Q180 | Ingreso: Q280)");
                            Console.WriteLine("3. Tomate    (Costo: Q250 | Ingreso: Q450)");
                            Console.WriteLine("4. Calabaza  (Costo: Q220 | Ingreso: Q360)");
                            Console.WriteLine("5. Espárrago (Costo: Q500 | Ingreso: Q1000)");
                            Console.WriteLine("6. Cancelar compra");

                            int opcSemilla;
                            Console.WriteLine("\nSeleccione la semilla a comprar:");
                            while (!int.TryParse(Console.ReadLine(), out opcSemilla) || opcSemilla < 1 || opcSemilla > 6)
                            {
                                Console.WriteLine("inválida. Seleccione del 1 al 6:");
                            }

                            if (opcSemilla != 6)
                            {
                                int cantidad;
                                Console.WriteLine("Ingrese la cantidad de semillas a comprar:");
                                while (!int.TryParse(Console.ReadLine(), out cantidad) || cantidad < 1)
                                {
                                    Console.WriteLine("inválida. Debe ser 1 o más:");
                                }

                                double costoUnitario = 0;
                                if (opcSemilla == 1) costoUnitario = 100;
                                else if (opcSemilla == 2) costoUnitario = 180;
                                else if (opcSemilla == 3) costoUnitario = 250;
                                else if (opcSemilla == 4) costoUnitario = 220;
                                else if (opcSemilla == 5) costoUnitario = 500;

                                double costoTotal = costoUnitario * cantidad;

                                if (dinero >= costoTotal)
                                {
                                    dinero -= costoTotal;
                                    totalMatPrima += costoTotal;

                                    if (opcSemilla == 1) invTrigo += cantidad;
                                    else if (opcSemilla == 2) invRepollo += cantidad;
                                    else if (opcSemilla == 3) invTomate += cantidad;
                                    else if (opcSemilla == 4) invCalabaza += cantidad;
                                    else if (opcSemilla == 5) invEsparrago += cantidad;

                                    Console.WriteLine($"\n¡Esta compra se completo! Se gastaron Q{costoTotal:F2}.");
                                }
                                else
                                {
                                    Console.WriteLine("\nFondos insuficientes para esta compra.");
                                }
                            }
                        }
                        else
                        {
                            Console.WriteLine("\nSu utilidad proyectada es negativa. por lo tanto no puedes hacer la compra.");
                        }
                        break;

                    case 2: // Sembrar
                        Console.WriteLine("\n--- Inventario Disponible ---");
                        Console.WriteLine($"1. Trigo: {invTrigo}");
                        Console.WriteLine($"2. Repollo: {invRepollo}");
                        Console.WriteLine($"3. Tomate: {invTomate}");
                        Console.WriteLine($"4. Calabaza: {invCalabaza}");
                        Console.WriteLine($"5. Espárrago: {invEsparrago}");

                        int fila;
                        Console.WriteLine($"\nIngrese la fila donde desea sembrar (0 a {numFilas - 1}):");
                        while (!int.TryParse(Console.ReadLine(), out fila) || fila < 0 || fila >= numFilas)
                        {
                            Console.WriteLine($"inválida. Debe ser un número entre 0 y {numFilas - 1}:");
                        }

                        int col;
                        Console.WriteLine($"Ingrese la columna donde desea sembrar (0 a {numColumnas - 1}):");
                        while (!int.TryParse(Console.ReadLine(), out col) || col < 0 || col >= numColumnas)
                        {
                            Console.WriteLine($"inválida. Debe ser un número entre 0 y {numColumnas - 1}:");
                        }

                        if (granja[fila, col].estaOcupada)
                        {
                            Console.WriteLine("\nError: Esta parcela ya se encuentra ocupada.");
                        }
                        else
                        {
                            int opcSiembra;
                            Console.WriteLine("\nSeleccione la semilla (1-Trigo, 2-Repollo, 3-Tomate, 4-Calabaza, 5-Espárrago):");
                            while (!int.TryParse(Console.ReadLine(), out opcSiembra) || opcSiembra < 1 || opcSiembra > 5)
                            {
                                Console.WriteLine("inválida. Seleccione un número entre 1 y 5:");
                            }

                            bool haySemilla = false;
                            string nombre = "";
                            int mCrecimiento = 0;
                            double ganancia = 0;

                            if (opcSiembra == 1 && invTrigo > 0) { haySemilla = true; invTrigo--; nombre = "Trigo"; mCrecimiento = 1; ganancia = 130; }
                            else if (opcSiembra == 2 && invRepollo > 0) { haySemilla = true; invRepollo--; nombre = "Repollo"; mCrecimiento = 2; ganancia = 280; }
                            else if (opcSiembra == 3 && invTomate > 0) { haySemilla = true; invTomate--; nombre = "Tomate"; mCrecimiento = 3; ganancia = 450; }
                            else if (opcSiembra == 4 && invCalabaza > 0) { haySemilla = true; invCalabaza--; nombre = "Calabaza"; mCrecimiento = 4; ganancia = 360; }
                            else if (opcSiembra == 5 && invEsparrago > 0) { haySemilla = true; invEsparrago--; nombre = "Esparrago"; mCrecimiento = 6; ganancia = 1000; }

                            if (haySemilla)
                            {
                                granja[fila, col].SembrarCultivo(nombre, mCrecimiento, ganancia);
                                Console.WriteLine($"\n¡Se ha sembrado {nombre} en la parcela [{fila}, {col}] exitosamente!");
                            }
                            else
                            {
                                Console.WriteLine("\nError: No tiene semillas disponibles de este tipo.");
                            }
                        }
                        break;

                    case 3: // Consultar
                        Console.WriteLine("\n--- Mapa de Parcelas ---");
                        Console.WriteLine("[L] = Libre | [O] = Ocupada");
                        for (int f = 0; f < numFilas; f++)
                        {
                            for (int c = 0; c < numColumnas; c++)
                            {
                                if (granja[f, c].estaOcupada) Console.Write("[O]\t");
                                else Console.Write("[L]\t");
                            }
                            Console.WriteLine();
                        }

                        int consFila;
                        Console.WriteLine($"\nIngrese la fila a consultar (0 a {numFilas - 1}):");
                        while (!int.TryParse(Console.ReadLine(), out consFila) || consFila < 0 || consFila >= numFilas)
                        {
                            Console.WriteLine($"Entrada inválida. Debe ser un número entre 0 y {numFilas - 1}:");
                        }

                        int consCol;
                        Console.WriteLine($"Ingrese la columna a consultar (0 a {numColumnas - 1}):");
                        while (!int.TryParse(Console.ReadLine(), out consCol) || consCol < 0 || consCol >= numColumnas)
                        {
                            Console.WriteLine($"inválida. Debe ser un número entre 0 y {numColumnas - 1}:");
                        }

                        Console.WriteLine($"--- Detalles de Parcela [{consFila}, {consCol}] ---");
                        if (!granja[consFila, consCol].estaOcupada)
                        {
                            Console.WriteLine("Estado: Libre");
                            Console.WriteLine("Ingresos esperados: Q0.00");
                        }
                        else
                        {
                            Console.WriteLine("Estado: Ocupada");
                            Console.WriteLine($"Tipo de siembra: {granja[consFila, consCol].tipoSiembra}");
                            Console.WriteLine($"Meses de crecimiento total: {granja[consFila, consCol].mesesCrecimiento}");
                            Console.WriteLine($"Meses faltantes para cosecha: {granja[consFila, consCol].mesesFaltantes}");
                            Console.WriteLine($"Ingresos esperados al cosechar: Q{granja[consFila, consCol].ingresosEsperados:F2}");
                        }
                        break;

                    case 4: // Avanzar mes
                        double pagoSalarios = numEmpleados * sueldoMensual;
                        dinero -= pagoSalarios;
                        mesesEfectivamenteSimulados++;

                        Console.WriteLine("--- Resumen de Avance de Mes ---");
                        Console.WriteLine($"Se pagaron Q{pagoSalarios:F2} en salarios.");

                        for (int f = 0; f < numFilas; f++)
                        {
                            for (int c = 0; c < numColumnas; c++)
                            {
                                if (granja[f, c].estaOcupada)
                                {
                                    granja[f, c].mesesFaltantes--;

                                    if (granja[f, c].mesesFaltantes == 0)
                                    {
                                        double ganancias = granja[f, c].ingresosEsperados;
                                        dinero += ganancias;
                                        totalIngresos += ganancias;

                                        Console.WriteLine($"¡Parcela [{f}, {c}] cosechada! {granja[f, c].tipoSiembra} generó Q{ganancias:F2}.");
                                        granja[f, c].CosecharCultivo();
                                    }
                                    else
                                    {
                                        Console.WriteLine($"Parcela [{f}, {c}] ({granja[f, c].tipoSiembra}) creció. Faltan {granja[f, c].mesesFaltantes} meses.");
                                    }
                                }
                            }
                        }
                        mesesRestantes--;

                        if (dinero <= 0)
                        {
                            Console.WriteLine("¡ALERTA! El dinero ha llegado a cero o menos. La simulación ha terminado por bancarrota.");
                        }
                        break;

                    case 5: // Salir y reporte final
                        salir = true;
                        break;
                }
            }

            
            double invEnProceso = 0.0;
            for (int f = 0; f < numFilas; f++)
            {
                for (int c = 0; c < numColumnas; c++)
                {
                    if (granja[f, c].estaOcupada)
                    {
                        invEnProceso += granja[f, c].ingresosEsperados;
                    }
                }
            }

            double totalManoObra = numEmpleados * sueldoMensual * mesesEfectivamenteSimulados;
            double utilidadesFormula = dineroInicial + totalIngresos + invEnProceso - totalManoObra - totalMatPrima;

            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("         REPORTE FINAL           ");
            Console.WriteLine("---------------------------------");
            if (mesesRestantes <= 0) Console.WriteLine("Causa de fin: Tiempo de simulación finalizado.");
            else if (dinero <= 0) Console.WriteLine("Causa de fin: Sin fondos (Bancarrota).");
            else Console.WriteLine("Causa de fin: Finalizado por el usuario.");

            Console.WriteLine($"\nCapital inicial:         Q{dineroInicial:F2}");
            Console.WriteLine($"Ingresos:                Q{totalIngresos:F2}");
            Console.WriteLine($"Inventario en proceso:   Q{invEnProceso:F2}");
            Console.WriteLine($"Mano de obra:            Q{totalManoObra:F2}");
            Console.WriteLine($"Materia Prima:           Q{totalMatPrima:F2}");
            Console.WriteLine("---------------------------------");
            Console.WriteLine($"Utilidades (Dinero en caja al final): Q{dinero:F2}");
            Console.WriteLine($"Utilidades (Según fórmula calculada): Q{utilidadesFormula:F2}");
            Console.WriteLine("---------------------------------");
        }
    }
}
        
    

