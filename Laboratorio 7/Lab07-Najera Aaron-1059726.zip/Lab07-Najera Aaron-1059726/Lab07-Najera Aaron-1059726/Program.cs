﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab07_Najera_Aaron_1059726
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombre = "<Ingrese su nombre>";
            int carnet = 1019126;
            int indice = 1;
            Console.WriteLine("Nombre: " + nombre + " carnet: " + carnet.ToString());
            while (indice <= 20)
            {
                if (indice % 2 == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Cyan;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                Console.WriteLine(indice);
                indice = indice + 1;
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadLine();
            //Ejercicio 2
            int numero;
            int i = 1;
            Console.WriteLine("-------------Sistema para encontrar el factorial de un numero entero positivo-------------");
            Console.WriteLine("Ingrese un numero entero positivo ");
            numero = int.Parse(Console.ReadLine());
            Console.WriteLine("Los divisores de tu numero son: " + numero);
            do
            {
                if (numero % i == 0)
                {
                    Console.WriteLine(i);
                }
                i = i + 1;

            }
            while (i <= numero);
            Console.ReadLine();
            //Ejercicio 3
            Console.WriteLine("-------------SERIE DE FIBONACCI-------------");
            Console.WriteLine("Coloca tu numero de elementos para la serie de Fibonacci");
            int n = int.Parse(Console.ReadLine());
            int M = 0;
            int A = 1;
            Console.WriteLine("Serie de Fibonacci ");
            for (i = 0; i < n; i++)
            {
                Console.WriteLine(M + " ");
                int siguente = M + A;
                M = A;
                A = siguente;
            }
            Console.ReadLine();
            //Ejercicio 4
            Console.WriteLine("-------------Tabla de Multiplicar-------------");
            for ( i = 1; i <= 12; i++)
            {
                Console.WriteLine("Tabla del " + i);

                for (int j = 1; j <= 10; j++)
                {
                    Console.WriteLine(i + " x " + j + " = " + (i * j));
                }
                Console.ReadLine();
            }

        }


    }
}

