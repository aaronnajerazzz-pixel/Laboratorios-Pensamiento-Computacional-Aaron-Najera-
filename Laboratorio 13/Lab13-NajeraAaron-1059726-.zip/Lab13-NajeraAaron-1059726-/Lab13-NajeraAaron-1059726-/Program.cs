﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_NajeraAaron_1059726_
{
    internal class Program
    {
        static void Main(string[] args)
        {
        Console.WriteLine("//////EJERCICIO 1//////");  
        PERSONA persona1 = new PERSONA();
        persona1.nombre = "Aaron";
            persona1.edad = 18;
            persona1.altura =1.75;  
            persona1.estudiante = true;

            Console.WriteLine("Nombre: " + persona1.nombre);
            Console.WriteLine("Edad: " + persona1.edad + " años");
            Console.WriteLine("Altura: " + persona1.altura + " m");
            Console.WriteLine("¿Es estudiante?: " + persona1.estudiante);
        //ejercicio 2
        Console.WriteLine("//////EJERCICIO 2//////");
        VEHICULO carro1 = new VEHICULO();
            carro1.anio = 2020;
            carro1.color = "azul";
            carro1.marca = "Toyota";
            carro1.modelo = "Corolla";
            carro1.placa = "ABC123";

            Console.WriteLine("Vehículo: " + carro1.marca + " " + carro1.modelo);
            Console.WriteLine("Año: " + carro1.anio);
            Console.WriteLine("Color: " + carro1.color);
            Console.WriteLine("Placa: " + carro1.placa);
        //ejercicio 3
        Console.WriteLine("//////EJERCICIO 3//////");
        PRODUCTO producto = new PRODUCTO();
            producto.precio = 19.99;
            producto .stock = 50;
            producto.disponible = false;
            producto.codigo = "P001";
            producto.nombre = "Camiseta";

        PRODUCTO producto2 = new PRODUCTO();
            producto2.disponible = true;
            producto2.precio = 29.99;
            producto2.stock = 20;
            producto2.codigo = "P002";
            producto2.nombre = "Pantalón";

            Console.WriteLine("Producto 1: " + producto.codigo + " | " + producto.nombre + " | Precio: Q" + producto.precio + " | Stock: " + producto.stock + " | Disponible: " + producto.disponible);
            Console.WriteLine("Producto 2: " + producto2.codigo + " | " + producto2.nombre + " | Precio: Q" + producto2.precio + " | Stock: " + producto2.stock + " | Disponible: " + producto2.disponible);
        //ejercicio 4
        Console.WriteLine("//////EJERCICIO 4//////");
            MASCOTA mascotitalindalindotaporfavordejemepasarseacompasivapofis = new MASCOTA();
            mascotitalindalindotaporfavordejemepasarseacompasivapofis.nombre = "aaron";
            mascotitalindalindotaporfavordejemepasarseacompasivapofis.edad = 3;
            mascotitalindalindotaporfavordejemepasarseacompasivapofis.especie = "perro";
            mascotitalindalindotaporfavordejemepasarseacompasivapofis.vacunado = true;
            mascotitalindalindotaporfavordejemepasarseacompasivapofis.peso = 10.5;

            Console.WriteLine("Nombre: " + mascotitalindalindotaporfavordejemepasarseacompasivapofis.nombre);
            Console.WriteLine("Especie: " + mascotitalindalindotaporfavordejemepasarseacompasivapofis.especie);
            Console.WriteLine("Edad: " + mascotitalindalindotaporfavordejemepasarseacompasivapofis.edad + " años");
            Console.WriteLine("Peso: " + mascotitalindalindotaporfavordejemepasarseacompasivapofis.peso + " kg");
            Console.WriteLine("¿Vacunado?: " + mascotitalindalindotaporfavordejemepasarseacompasivapofis.vacunado);



        }
}
}
