﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_NajeraAaron_1059726_
{
    class MASCOTA
    {
        public string nombre;
        public string especie;
        public int edad;
        public double peso;
        public bool vacunado;
    }
}
