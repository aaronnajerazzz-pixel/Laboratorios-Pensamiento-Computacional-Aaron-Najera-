﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_NajeraAaron_1059726_
{
    class PERSONA
    {
    public string nombre;
        public int edad;
        public double altura;
        public bool estudiante;
    }
}

