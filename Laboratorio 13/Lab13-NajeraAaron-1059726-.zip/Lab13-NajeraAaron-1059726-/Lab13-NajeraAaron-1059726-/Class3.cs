﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_NajeraAaron_1059726_
{
    class PRODUCTO
    {
        public string codigo;
        public string nombre;
        public double precio;
        public int stock;
        public bool disponible;
    }
}
