﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13_NajeraAaron_1059726_
{
   class VEHICULO
    {
    public string marca;
        public string modelo;
        public int anio;
        public string color;
        public string placa;
    }
}

