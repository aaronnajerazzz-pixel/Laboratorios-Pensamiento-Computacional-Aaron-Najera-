﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11_AaronNajeraMorales_1059726
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ejercicioUno
         void EjercicioUno()
            {
                Console.Write("Ingrese una palabra: ");
                string palabra = Console.ReadLine().ToLower();
                char[] caracteres = palabra.ToCharArray();
                bool esPalindromo = true;
                for (int i = 0; i < caracteres.Length / 2; i++)
                {
                    if (caracteres[i] != caracteres[caracteres.Length - 1 - i])
                    {
                        esPalindromo = false;
                        break;
                    }
                }
                Console.WriteLine("¿Es palíndromo?: " + esPalindromo);
            }

            // ejercicioDos
           void EjercicioDos()
            {
                string[] espanol = { "rojo", "azul", "amarillo", "blanco", "verde" };
                string[] ingles = { "red", "blue", "yellow", "white", "green" };
                string[] italiano = { "rosso", "blu", "giallo", "bianco", "verde" };
                int opcion;
                do
                {
                    Console.WriteLine("1.INICIO");
                    Console.WriteLine("2. FIN");
                    Console.Write("elige la opción: ");
                    opcion = int.Parse(Console.ReadLine());

                    if (opcion == 1)
                    {
                        Console.Write("elige una palabra en español: ");
                        string palabra = Console.ReadLine().ToLower();
                        int index = -1;
                        for (int i = 0; i < espanol.Length; i++)
                        {
                            if (espanol[i] == palabra)
                            {
                                index = i;
                                break;
                            }
                        }

                        if (index != -1)
                        {
                            Console.WriteLine($"{espanol[index]}, {ingles[index]}, {italiano[index]}");
                        }
                        else
                        {
                            Console.WriteLine("La palabra no coincide ");
                        }
                    }

                } while (opcion != 2);
            }

            // ejercicioTres
             void EjercicioTres()
            {
                Random rnd = new Random();
                int[] notas = new int[10];
                for (int i = 0; i < notas.Length; i++)
                {
                    notas[i] = rnd.Next(50, 101);
                }
                int opcion;
                do
                {
                    Console.WriteLine("1. Reporte de rendimiento");
                    Console.WriteLine("2. Estadísticas");
                    Console.WriteLine("3. Salir");
                    Console.Write("Seleccione opción: ");
                    opcion = int.Parse(Console.ReadLine());

                    if (opcion == 1)
                    {
                        foreach (int n in notas)
                        {
                            if (n <= 64)
                                Console.ForegroundColor = ConsoleColor.Red;
                            else if (n <= 79)
                                Console.ForegroundColor = ConsoleColor.Yellow;
                            else
                                Console.ForegroundColor = ConsoleColor.Green;

                            Console.Write(n + " ");
                        }
                        Console.ResetColor();
                        Console.WriteLine();
                    }
                    else if (opcion == 2)
                    {
                        int suma = 0, mayor = notas[0], menor = notas[0];
                        foreach (int n in notas)
                        {
                            suma += n;
                            if (n > mayor) mayor = n;
                            if (n < menor) menor = n;
                        }
                        double promedio = (double)suma / notas.Length;
                        Console.WriteLine("Promedio: " + promedio);
                        Console.WriteLine("Mayor: " + mayor);
                        Console.WriteLine("Menor: " + menor);
                    }

                } while (opcion != 3);
            }
            // ejercicioCuatro
             void EjercicioCuatro()
            {
                string[] nombres = { "Ana", "Mario", "Saúl", "Karla", "María", "José" };
                double[] salario = { 100, 125.50, 98.65, 125, 132.50, 102.50 };
                double[] horas = new double[6];

                for (int i = 0; i < nombres.Length; i++)
                {
                    Console.Write($"Horas trabajadas: {nombres[i]}: ");
                    horas[i] = double.Parse(Console.ReadLine());
                }

                Console.WriteLine("Pagos semanales:");

                for (int i = 0; i < nombres.Length; i++)
                {
                    double pago;

                    if (horas[i] <= 40)
                    {
                        pago = horas[i] * salario[i];
                    }
                    else
                    {
                        double extras = horas[i] - 40;
                        pago = (40 * salario[i]) + (extras * salario[i] * 1.5);
                    }

                    Console.WriteLine($"{nombres[i]}: Q{pago}");
                }

            }
        }
    }
}
